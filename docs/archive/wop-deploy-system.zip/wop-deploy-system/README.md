# WoP Deploy

**Words of Plainness Chapter Deployment Automation System**

Automates the entire chapter deployment workflow for [words-of-plainness.vercel.app](https://words-of-plainness.vercel.app), reducing deployment time from 6-10 hours of manual work to ~30 minutes of content gathering plus automated processing.

---

## 🎯 What This System Does

| Step | Manual Time | Automated |
|------|-------------|-----------|
| File organization | 30+ min | ✅ Instant |
| SRT → JSON timestamps | 20 min | ✅ Whisper generates from audio |
| HTML → Markdown conversion | 60+ min | ✅ Automatic with sentence wrapping |
| Audio sync verification | 30+ min | ✅ Automatic validation |
| Preflight checks | 20+ min | ✅ Comprehensive auto-checks |
| Git commit/push | 10 min | ✅ One command |
| Deployment verification | 15 min | ✅ Auto-generated report |

---

## 📦 Installation

```bash
# Clone or copy to your project
cd words-of-plainness
git clone <this-repo> wop-deploy

# Install dependencies
cd wop-deploy
npm install

# Link globally (optional)
npm link
```

### Dependencies

- **Node.js 18+** - Runtime
- **ffprobe** - Audio duration analysis (install via ffmpeg)
- **Whisper** - Speech-to-text for timestamps (optional but recommended)

```bash
# Install ffmpeg (includes ffprobe)
# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt install ffmpeg

# Install Whisper (optional, for automatic timestamps)
pip install openai-whisper
```

---

## 🚀 Quick Start

### Option 1: Interactive Wizard (Recommended)

```bash
wop wizard
```

The wizard guides you through the entire process with prompts.

### Option 2: Step-by-Step Commands

```bash
# 1. Initialize staging folder with checklist
wop init 4 --title "The First Principles of the Gospel"

# 2. [You collect files into staging folder]

# 3. Validate all files are present
wop validate 4

# 4. Process files (generates markdown, timestamps)
wop process 4

# 5. Verify audio sync
wop sync-check 4

# 6. Run preflight checks
wop preflight 4

# 7. Deploy
wop deploy 4

# 8. Generate report
wop report 4
```

### Option 3: Full Pipeline (After Files Ready)

```bash
wop full 4
```

---

## 📁 Workflow Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                      CONTENT CREATION (You)                         │
├─────────────────────────────────────────────────────────────────────┤
│  1. Write chapter manuscript                                        │
│  2. Run theological editing with Claude → HTML output               │
│  3. Generate audio with ElevenLabs → MP3                           │
│  4. Create study slides → PNG exports                              │
│  5. Export PDF                                                      │
│  6. (Optional) Create musical testimony, overview, infographic      │
└─────────────────────────────────────────────────────────────────────┘
                                  ↓
┌─────────────────────────────────────────────────────────────────────┐
│                    AUTOMATION (WoP Deploy)                          │
├─────────────────────────────────────────────────────────────────────┤
│  wop init        → Create staging folders with checklist            │
│  wop validate    → Verify all files present and named correctly     │
│  wop process     → Convert HTML→MD, generate Whisper timestamps     │
│  wop sync-check  → Verify audio/text synchronization                │
│  wop preflight   → Build test, navigation, validation               │
│  wop deploy      → Git commit, push, Vercel auto-deploys            │
│  wop report      → Generate activity report for review              │
└─────────────────────────────────────────────────────────────────────┘
                                  ↓
┌─────────────────────────────────────────────────────────────────────┐
│                       LIVE SITE                                     │
│              words-of-plainness.vercel.app                          │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📋 File Manifest

When you run `wop init`, a staging folder is created with this structure:

```
wop-staging/chapter-04/
├── audio/
│   ├── chapter-04-narration.mp3     ← REQUIRED
│   ├── chapter-04-overview.mp3      ← Optional
│   └── 04_1_Song_Title_-_Sacred_Americana_Testimony.mp3  ← Optional
├── documents/
│   ├── WoP_Ch04_Title.html          ← REQUIRED (from Claude editing)
│   └── WoP_Ch04_Title.pdf           ← REQUIRED
├── images/
│   └── chapter-04-infographic.png   ← Optional
├── slides/
│   ├── slide-01.png                 ← REQUIRED (at least 3)
│   ├── slide-02.png
│   └── ...
├── manifest.json                    ← Auto-generated
└── README.md                        ← Checklist
```

### Required Files

| File | Source | Description |
|------|--------|-------------|
| `WoP_Ch##_Title.html` | Claude editing session | Edited chapter with headings |
| `chapter-##-narration.mp3` | ElevenLabs | Full chapter audio |
| `WoP_Ch##_Title.pdf` | Word export | Downloadable PDF |
| `slide-01.png` through `slide-##.png` | Slides export | Study slides |

### Optional Files

| File | Source | Description |
|------|--------|-------------|
| `##_1_Title_-_Sacred_Americana_Testimony.mp3` | Suno AI | Musical testimony |
| `chapter-##-overview.mp3` | ElevenLabs | Podcast overview |
| `chapter-##-infographic.png` | Canva | Visual summary |

---

## 🔧 Commands Reference

### `wop manifest <chapter>`

Generate file manifest showing what files are needed.

```bash
wop manifest 4 --title "The First Principles"
wop manifest 4 --output manifest.json
```

### `wop init <chapter>`

Create staging folder structure with README checklist.

```bash
wop init 4 --title "The First Principles"
wop init 4 --force  # Overwrite existing
```

### `wop validate <chapter>`

Check all required files are present and correctly named.

```bash
wop validate 4
wop validate 4 --staging /custom/path
wop validate 4 --strict  # Fail on warnings
```

### `wop process <chapter>`

Process files: HTML→Markdown, generate Whisper timestamps, copy assets.

```bash
wop process 4
```

### `wop sync-check <chapter>`

Verify audio timestamps match sentence count.

```bash
wop sync-check 4
wop sync-check 4 --fix      # Auto-fix issues
wop sync-check 4 --verbose  # Show timing details
```

### `wop preflight <chapter>`

Run all pre-deployment checks.

```bash
wop preflight 4
wop preflight 4 --skip-build  # Skip npm build test
```

### `wop deploy <chapter>`

Commit, push, and trigger Vercel deployment.

```bash
wop deploy 4
wop deploy 4 --message "Custom commit message"
wop deploy 4 --dry-run  # Show what would happen
wop deploy 4 --no-push  # Commit only, don't push
```

### `wop report <chapter>`

Generate deployment activity report.

```bash
wop report 4
wop report 4 --output report.md
wop report 4 --format html
wop report 4 --format json
```

### `wop full <chapter>`

Run complete pipeline: validate → process → sync-check → preflight → deploy → report.

```bash
wop full 4
wop full 4 --skip-deploy  # Stop before deployment
```

### `wop wizard`

Interactive deployment wizard with prompts.

```bash
wop wizard
```

---

## ⚙️ Configuration

Create `wop.config.yaml` in your project root to customize:

```yaml
stagingFolder: ./wop-staging

paths:
  chapters: src/chapters
  timestamps: src/_data/timestamps
  audio: src/assets/audio
  pdf: src/assets/pdf
  images: src/assets/images
  slides: src/assets/slides

naming:
  chapter: "{chapter}-{slug}.md"
  timestamps: "chapter-{chapter}-{slug}.json"
  narration: "chapter-{chapter}-narration.mp3"

audio:
  elevenLabsVoiceId: As8zJaZyH4MAgaQ93FMc

deploy:
  branch: main
  remote: origin

discord:
  serverInvite: https://discord.gg/tNwADDjTRV
```

---

## 🔄 Timestamp Generation

The system uses OpenAI Whisper to automatically generate sentence-level timestamps from audio:

1. **Whisper transcribes** the narration audio
2. **Segments are mapped** to sentences in the markdown
3. **JSON file is generated** with sentence index → timestamp mapping

```json
{
  "0": 0.0,
  "1": 3.24,
  "2": 7.89,
  "3": 12.45
}
```

### Fallback: SRT Files

If Whisper isn't available, place an SRT file in the staging folder:

```
staging/audio/chapter-04-narration.srt
```

The system will convert it to the JSON timestamp format.

---

## 🐛 Troubleshooting

### "Whisper not installed"

```bash
pip install openai-whisper
# or use SRT fallback
```

### "Timestamp count mismatch"

Run sync-check with fix:
```bash
wop sync-check 4 --fix
```

### "Build failed"

Check for syntax errors:
```bash
cd words-of-plainness
npm run build
```

### "Audio file not found"

Verify naming convention: `chapter-##-narration.mp3`

---

## 📊 Learning from Deployments

Reports are archived in `.wop-reports/` for debugging patterns:

```bash
# View all reports
ls .wop-reports/

# Find common errors
grep -r "failed" .wop-reports/
```

---

## 🎯 Best Practices

1. **Run `wop init` first** - Creates checklist so you don't forget files
2. **Validate before processing** - Catches naming issues early
3. **Check sync after processing** - Ensures audio matches text
4. **Use wizard for new chapters** - Guided experience
5. **Review reports** - Learn from any issues

---

## 📝 License

MIT - Use freely for the glory of God.

---

*"For my soul delighteth in plainness"* — 2 Nephi 31:3
