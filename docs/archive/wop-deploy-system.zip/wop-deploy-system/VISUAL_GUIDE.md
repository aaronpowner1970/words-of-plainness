# WoP Chapter Deployment Visual Guide

## 📋 Pre-Flight Checklist

Print this page and check off items as you complete them.

---

## Phase 1: Content Creation

### 1.1 Theological Editing
```
[ ] Open manuscript in theological editing session with Claude
[ ] Apply editing prompt (WoP_Theological_Editing_Prompt_v2_0.docx)
[ ] Review and accept all changes
[ ] Save HTML output: WoP_Ch##_Title.html
[ ] Save DOCX output: WoP_Ch##_Title.docx
```

### 1.2 Audio Production
```
[ ] Export plain text for narration script
[ ] Generate audio with ElevenLabs
    Voice ID: As8zJaZyH4MAgaQ93FMc
[ ] Download MP3: chapter-##-narration.mp3
[ ] (Optional) Create musical testimony with Suno AI
[ ] (Optional) Create overview podcast
```

### 1.3 Visual Assets
```
[ ] Create study slides (Google Slides or PowerPoint)
[ ] Export slides as PNG: slide-01.png, slide-02.png, ...
[ ] Export PDF: WoP_Ch##_Title.pdf
[ ] (Optional) Create infographic: chapter-##-infographic.png
```

---

## Phase 2: Automation

### 2.1 Initialize
```bash
wop init ## --title "Your Chapter Title"
```
Creates: `wop-staging/chapter-##/`

### 2.2 Collect Files
Copy files to staging folders:
```
wop-staging/chapter-##/
├── audio/
│   └── chapter-##-narration.mp3      ✓
├── documents/
│   ├── WoP_Ch##_Title.html           ✓
│   └── WoP_Ch##_Title.pdf            ✓
├── slides/
│   ├── slide-01.png                  ✓
│   ├── slide-02.png                  ✓
│   └── ...                           ✓
└── images/
    └── (optional infographic)
```

### 2.3 Validate
```bash
wop validate ##
```
Expected output: `✓ Validation PASSED`

### 2.4 Process
```bash
wop process ##
```
Auto-generates:
- Markdown with sentence wrapping
- Timestamps JSON via Whisper
- Copies all assets to repo

### 2.5 Sync Check
```bash
wop sync-check ##
```
Verifies: sentence count = timestamp count

### 2.6 Preflight
```bash
wop preflight ##
```
Checks:
- Git status
- All files in repo
- Frontmatter valid
- Build succeeds

### 2.7 Deploy
```bash
wop deploy ##
```
Actions:
- Git add
- Git commit
- Git push
- Vercel auto-deploys

### 2.8 Report
```bash
wop report ##
```
Generates deployment summary

---

## Quick Command Reference

| Task | Command |
|------|---------|
| Start new chapter | `wop wizard` |
| Create staging | `wop init ##` |
| Check files | `wop validate ##` |
| Process all | `wop process ##` |
| Check sync | `wop sync-check ##` |
| Pre-deploy | `wop preflight ##` |
| Deploy | `wop deploy ##` |
| Full pipeline | `wop full ##` |
| Get report | `wop report ##` |

---

## File Naming Conventions

| File Type | Naming Pattern |
|-----------|---------------|
| Markdown | `##-slug.md` |
| Timestamps | `chapter-##-slug.json` |
| Narration | `chapter-##-narration.mp3` |
| Overview | `chapter-##-overview.mp3` |
| Testimony | `##_1_Title_-_Sacred_Americana_Testimony.mp3` |
| PDF | `WoP_Ch##_Title.pdf` |
| Infographic | `chapter-##-infographic.png` |
| Slides | `slide-01.png`, `slide-02.png`, ... |

---

## Post-Deployment Checklist

```
[ ] Verify live at https://words-of-plainness.vercel.app
[ ] Navigate to new chapter
[ ] Test audio playback
[ ] Verify sentence highlighting syncs
[ ] Test click-to-seek
[ ] Check study slides carousel
[ ] Test PDF download
[ ] Verify on mobile
[ ] Update previous chapter's nextChapter link
[ ] Post in Discord #announcements
```

---

## Troubleshooting Quick Fixes

| Problem | Solution |
|---------|----------|
| Validation fails | Check file names match convention |
| Whisper fails | Install: `pip install openai-whisper` |
| Sync mismatch | Run: `wop sync-check ## --fix` |
| Build fails | Check: `npm run build` in project |
| Push fails | Verify git credentials |

---

## Emergency Rollback

If deployment breaks the site:

```bash
# Option 1: Git revert
git revert HEAD
git push origin main

# Option 2: Vercel dashboard
# Go to Deployments → Previous → Promote to Production
```

---

## Time Estimates

| Phase | Manual | With Automation |
|-------|--------|-----------------|
| Theological editing | 1-2 hrs | 1-2 hrs (no change) |
| Audio production | 2-3 hrs | 2-3 hrs (no change) |
| Visual assets | 1-2 hrs | 1-2 hrs (no change) |
| File organization | 30 min | 2 min |
| Timestamp creation | 30 min | 2 min (Whisper) |
| HTML→MD conversion | 1 hr | 1 min |
| Sync verification | 30 min | 1 min |
| Deployment | 30 min | 2 min |
| **TOTAL** | **7-10 hrs** | **5-7 hrs** |

**Automation saves 2-3 hours per chapter × 60 chapters = 120-180 hours saved**

---

*Last updated: January 2026*
